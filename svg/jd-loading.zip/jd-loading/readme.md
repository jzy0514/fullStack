loading  gif图
GIF 设计 4kb-> 14kb
sng 省空间